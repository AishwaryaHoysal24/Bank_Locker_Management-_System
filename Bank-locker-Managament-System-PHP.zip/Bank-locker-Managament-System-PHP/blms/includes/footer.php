
  <div class="footer-bot">
  <div class="container">
    <div class="logo2">
      <h2><a href="index.php"><span>Bank Locker</span> Management System</a></h2>
    </div>
    <div class="clearfix"></div>
  </div>
</div>
<div class="copy-right">
  <div class="agileinfo_social_icons">
    <ul class="agileits_social_list">
      <li><a href="#" class="w3_agile_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
      <li><a href="#" class="agile_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
      <li><a href="#" class="w3_agile_dribble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
      <li><a href="#" class="w3_agile_google"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
    </ul>
  </div>
  <div class="container">
    <p> Bank Locker Management System</p>
  </div>
</div>
<!-- //footer -->